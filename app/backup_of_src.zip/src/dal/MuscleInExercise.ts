export type MuscleInExercise = {
  exerciseId: number
  muscleId: number
  contractionType: string
  fatigueAccumulationFactor: string
  muscleMovementCategory: string
}
